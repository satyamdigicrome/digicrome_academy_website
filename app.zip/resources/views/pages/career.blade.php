@extends('layouts.app')

@section('title', 'Home Page')

@section('content')








@endsection