

<?php $__env->startSection('title', 'Home Page'); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Administrator\Videos\digicrome_website_new\resources\views/pages/success_stories.blade.php ENDPATH**/ ?>