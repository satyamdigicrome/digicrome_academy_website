
<!-- ========= Prealoader ==============-->

<!--========= End Prealoader ============== -->




<!--==================================================-->
<!-- Start educate Header top area -->
<!--==================================================-->
<div class="header-top-area">
	<div class="container-fluid">
		<div class="row header-top">
			<div class="col-xxl-6 col-xl-8 col-lg-8">
				<div class="header-top-welcome">
					<p>Welcome to <a href="/">Digicrome Pvt. Ltd.</a>Think Big Think Digital</p>
				</div>
			</div>
			<div class="col-xxl-6 col-xl-4 col-lg-4">
				<div class="header-top-right">
					<div class="educate-header-from">
						<a class="login-btn" href="sign-in.html"><i class="bi bi-arrow-right-circle"></i>Login</a>
						<a class="sign-up-btn" href="sign-up.html"><i class="bi bi-person-plus"></i>Register</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!--==================================================-->
<!-- End educate Header top area -->
<!--==================================================-->





<!--==================================================-->
<!-- Start educate Header Area-->
<!--==================================================-->
<div class="educate-header-area" id="sticky-header" >
	<div class="container-fluid">
		<div class="row header-wrap align-items-center">
			<div class="col-lg-2">
				<div class="header-logo">
					<a class="active_logo" href="/"><img src="assets/images/logo.webp" alt="logo"></a>
					<a class="logo_two" href="/"><img src="assets/images/footer-logo.webp" alt="logo"></a>
				</div>
			</div>
			<div class="col-lg-8">
				<div class="header-menu">
					<ul class="nav_scroll">
						<li><a href="/">Home</a>
						</li>
						<li><a href="<?php echo e(route('about')); ?>">About</a></li>
						
						<li><a href="#">courses<i class="bi bi-chevron-down"></i></a>
							<ul class="sub_menu">
								<li><a href="<?php echo e(route('course')); ?>">Courses</a></li>
								<li><a href="course-details.html">Courses Details</a></li>
							</ul>
						</li>
						
						<li><a href="<?php echo e(route('corporate_services')); ?>">Corporate Services </a>
						<li><a href="<?php echo e(route('blog')); ?>">Blog </a>
						<li><a href="<?php echo e(route('payments')); ?>">Payments </a>
							
						</li>
						<li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
						<li><a href="#">More<i class="bi bi-chevron-down"></i></a>
					<ul class="sub_menu">
						<li><a href="<?php echo e(route('who_we_are')); ?>">Who we are</a></li>
						<li><a href="<?php echo e(route('success_stories')); ?>">Success stories</a></li>
						<li><a href="<?php echo e(route('refer_and_earn')); ?>">Refer & Earn</a></li>
						<li><a href="<?php echo e(route('career')); ?>">Career</a></li>
						<li><a href="<?php echo e(route('media_presence')); ?>">Media Presence</a></li>

					</ul>
				</li>
					</ul>				
				</div>
			</div>
			<div class="col-lg-2">
				<div class="header-right-wrapper">
					<div class="header-sidebar">
						
						
						<div class="header-btn search-box-btn search-box-outer">
							<a href="#">Contact<i class="flaticon flaticon-right-arrow"></i></a>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End educate Header Area -->
<!--==================================================-->

<!--========= Start Mobile Memu========== -->

<div class="mobile-menu-area sticky d-sm-block d-md-block d-lg-none">
	<div class="mobile-menu">
		<nav class="header-menu">
			<div class="mobile-logo">
				<a class="logo_img" href="/" title="educate">
				    <img src="assets/images/footer-logo.webp" alt="logo">
				</a>
			  </div>
			  <ul class="nav_scroll">
				<li><a href="/">Home</a>
					
				</li>
				<li><a href="<?php echo e(route('about')); ?>">about</a></li>
				
				<li><a href="#">courses<i class="bi bi-chevron-down"></i></a>
					<ul class="sub_menu">
						<li><a href="<?php echo e(route('course')); ?>">Courses</a></li>
						<li><a href="course-details.html">Courses Details</a></li>
					</ul>
				</li>
				
				<li><a href="<?php echo e(route('corporate_services')); ?>">Corporate Services </a>
				<li><a href="<?php echo e(route('blog')); ?>">Blog</a>
				<li><a href="<?php echo e(route('payments')); ?>">Payments </a>
					
				</li>
				<li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
				<li><a href="#">More<i class="bi bi-chevron-down"></i></a>
					<ul class="sub_menu">
						<li><a href="<?php echo e(route('who_we_are')); ?>">Who we are</a></li>
						<li><a href="<?php echo e(route('success_stories')); ?>">Success stories</a></li>
						<li><a href="<?php echo e(route('refer_and_earn')); ?>">Refer & Earn</a></li>
						<li><a href="<?php echo e(route('career')); ?>">Career</a></li>
					</ul>
				</li>
			</ul>	
		</nav>
	</div>
</div>
<!--========= End Mobile Memu========== -->



<!--==================================================-->
<!-- Start Search Popup -->
<!--==================================================-->
<div class="search-popup">
<button class="close-search style-two"><i class="fas fa-times"></i></button>
<button class="close-search"><i class="fas fa-arrow-up"></i></button>
<form method="post" action="#">
	<div class="form-group">
		<input id="search1" type="search" name="search-field" value="" placeholder="Search Here" required="">
		<button  type="submit"><i class="fas fa-search"></i></button>
	</div>
</form>
</div>
<!--==================================================-->
<!-- End Search Popup -->
<!--==================================================-->





<!--==================================================-->
<!-- Start Cart Side Bar -->
<!--==================================================-->
<div class="sidebar-menu-wrapper">
	<div class="cart_sidebar">
		<button type="button" class="close_btn"><i class="fas fa-times"></i></button>
		<h2 class="heading_title text-uppercase">Cart Items - <span>4</span></h2>

		<div class="cart_items_list">
			<div class="cart_item">
				<div class="item_image">
					<img src="assets/images/inner-img/rpost-thumb1.webp" alt="image_not_found">
				</div>
				<div class="item_content">
					<h4 class="item_title">	
					How Gamification is Changing the Way...
					</h4>
					<span class="item_price">$21.00</span>
					<button type="button" class="remove_btn"><i class="fas fa-times"></i></button>
				</div>
			</div>

			<div class="cart_item">
				<div class="item_image">
					<img src="assets/images/inner-img/rpost-thumb2.webp" alt="image_not_found">
				</div>
				<div class="item_content">
					<h4 class="item_title">
						Learning is the Key soft skills and Professional
					</h4>
					<span class="item_price">$23.00</span>
					<button type="button" class="remove_btn"><i class="fas fa-times"></i></button>
				</div>
			</div>

			<div class="cart_item">
				<div class="item_image">
					<img src="assets/images/inner-img/rpost-thumb3.webp" alt="image_not_found">
				</div>
				<div class="item_content">
					<h4 class="item_title">
						The Importance of Critical Thinking in Education
					</h4>
					<span class="item_price">$25.00</span>
					<button type="button" class="remove_btn"><i class="fas fa-times"></i></button>
				</div>
			</div>

			<div class="cart_item">
				<div class="item_image">
					<img src="assets/images/inner-img/rpost-thumb2.webp" alt="image_not_found">
				</div>
				<div class="item_content">
					<h4 class="item_title">
						Learning is the Key soft skills and Professional
					</h4>
					<span class="item_price">$19.00</span>
					<button type="button" class="remove_btn"><i class="fas fa-times"></i></button>
				</div>
			</div>
		</div>
		<div class="total_price text-uppercase">
			<span>Sub Total:</span>
			<span>$88.00</span>
		</div>
		<ul class="btns_group ul_li">
			<li><a href="cart.html" class="btn btn_primary text-uppercase">View Cart</a></li>
			<li><a href="checkout.html" class="btn btn_border border_black text-uppercase">Checkout</a></li>
		</ul>
	</div>
	<div class="cart_sidebar_overlay"></div>
</div>
<!--==================================================-->
<!-- End Cart Side Bar -->
<!--==================================================-->

<!-- Sidebar Cart Item -->
<div class="xs-sidebar-group info-group">
	<div class="xs-overlay xs-bg-black"></div>
	<div class="xs-sidebar-widget">
		<div class="sidebar-widget-container">
			<div class="widget-heading">
				<a href="#" class="close-side-widget">
					<i class="far fa-times-circle"></i>
				</a>
			</div>
			<div class="sidebar-textwidget">
				<!-- Sidebar Info Content -->
				<div class="sidebar-info-contents">
					<div class="content-inner">
						<div class="nav-logo">
							<a href="/"><img src="assets/images/home-one/footer-logo.webp" alt="logo"></a>
						</div>
						<div class="content-box">
							<h2>About Us</h2>
							<p class="text">The argument in favor of using filler text goes something like this: If
								you use real content in the Consulting Process, anytime you reach a review point
								you’ll end up reviewing and negotiating the content itself and not the design.</p>
							<a href="index-7.html" class="theme-btn btn-style-two"><span>Consultation</span> <i class="fas fa-heart"></i></a>
						</div>
						<div class="contact-info">
							<h2>Contact Info</h2>
							<ul class="list-style-one">
								<li><span class="icon flaticon-email"></span>Chicago 12, Melborne City, USA</li>
								<li><span> <i class="bi bi-telephone-inbound"></i> </span>(+001) 123-456-7890</li>
								<li><span><i class="bi bi-geo-alt"></i></span>Example @gmail.com</li>
								<li><span><i class="bi bi-clock"></i></span>Week Days: 09.00 to 18.00 Sunday: Closed
								</li>
							</ul>
						</div>
						<!-- Social Box -->
						<ul class="social-box">
							<li class="facebook"><a href="#" class="fab fa-facebook-f"></a></li>
							<li class="twitter"><a href="#" class="fab fa-instagram"></a></li>
							<li class="linkedin"><a href="#" class="fa-brands fa-x-twitter"></a></li>
							<li class="instagram"><a href="#" class="fab fa-pinterest-p"></a></li>
							<li class="youtube"><a href="#" class="fab fa-linkedin-in"></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--End Sidebar Cart Item --><?php /**PATH C:\Users\Administrator\Videos\digicrome_website_new\resources\views/layouts/header.blade.php ENDPATH**/ ?>